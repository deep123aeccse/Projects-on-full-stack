package com.buyout.sale.buyout.models;

import java.util.ArrayList;

public class BBjsonDeserializer {
    public ArrayList<CompareProduct> products;


}
