package com.buyout.sale.buyout.models;

public class Review {
}
