package com.buyout.sale.buyout.repository;

public interface ReviewRepository {
}
