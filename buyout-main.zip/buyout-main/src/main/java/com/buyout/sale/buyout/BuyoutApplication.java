package com.buyout.sale.buyout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuyoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuyoutApplication.class, args);
	}

}
